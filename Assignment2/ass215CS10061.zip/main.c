// The printStr uses char * hence typecasting has been done
// for all calls to printStr
#include "myl.h"
int main(){
	int n, size;
	float f;
	size = printStr((char *)"Enter an integer");
	if(readInt(&n)==ERR)
		printStr((char *)"Invalid integer");
	else
		size = printInt(n);
	printStr((char *)"Enter a float");
	if(readFlt(&f)==ERR)
		printStr((char *)"Invalid float");
	else 
		size = printFlt(f);
	return 0;
}


