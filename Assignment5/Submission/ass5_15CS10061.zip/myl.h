#ifndef _MYL_H
#define _MYL_H
#define ERR 1
#define OK 0
int printStr(char *s);
int printInt(int i);
int readInt(int *i);
int readFlt(double *f);
int printFlt(double f);
#endif
